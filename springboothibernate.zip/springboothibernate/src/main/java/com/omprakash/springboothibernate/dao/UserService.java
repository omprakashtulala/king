package com.omprakash.springboothibernate.dao;

import com.omprakash.springboothibernate.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
