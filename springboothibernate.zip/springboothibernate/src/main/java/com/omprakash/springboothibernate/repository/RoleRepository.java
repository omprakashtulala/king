package com.omprakash.springboothibernate.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.omprakash.springboothibernate.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{
}
